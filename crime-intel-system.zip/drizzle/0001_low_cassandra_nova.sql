CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`alertType` enum('critical_incident','high_risk_suspect','urgent_review','system_alert') NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`relatedEntityType` varchar(50),
	`relatedEntityId` int,
	`recipientIds` text,
	`sentAt` timestamp,
	`readAt` timestamp,
	`emailSentAt` timestamp,
	`status` enum('pending','sent','read') DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileType` varchar(50),
	`fileSize` int,
	`s3Key` varchar(500),
	`s3Url` text,
	`uploadedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`entityType` varchar(50),
	`entityId` int,
	`oldValue` json,
	`newValue` json,
	`ipAddress` varchar(45),
	`userAgent` text,
	`status` enum('success','failure') DEFAULT 'success',
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`incidentTitle` varchar(255) NOT NULL,
	`incidentDate` timestamp NOT NULL,
	`incidentLocation` varchar(255),
	`latitude` decimal(10,8),
	`longitude` decimal(11,8),
	`incidentType` varchar(100),
	`description` text NOT NULL,
	`relatedSuspectIds` text,
	`relatedTargetIds` text,
	`sourceId` int,
	`reportedBy` int NOT NULL,
	`supervisorId` int,
	`status` enum('open','under_investigation','closed') DEFAULT 'open',
	`priority` enum('low','medium','high','critical') DEFAULT 'medium',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incidents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `intelligence_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportTitle` varchar(255) NOT NULL,
	`reportContent` text NOT NULL,
	`reportType` varchar(100),
	`sourceId` int NOT NULL,
	`incidentId` int,
	`authorId` int NOT NULL,
	`supervisorId` int,
	`status` enum('draft','submitted','under_review','approved','rejected') DEFAULT 'draft',
	`priority` enum('low','medium','high','critical') DEFAULT 'medium',
	`confidentialityLevel` enum('public','internal','restricted','confidential') DEFAULT 'restricted',
	`relatedSuspectIds` text,
	`relatedTargetIds` text,
	`extractedEntities` json,
	`extractedRelationships` json,
	`riskAssessment` json,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`submittedAt` timestamp,
	`approvedAt` timestamp,
	CONSTRAINT `intelligence_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceType` enum('confidential_informant','public_tip','surveillance','digital_evidence','agency_report','undercover','forensic','osint') NOT NULL,
	`sourceIdentifier` varchar(255),
	`sourceIdentityEncrypted` binary NOT NULL,
	`sourceIdentityIV` varchar(32),
	`sourceReliabilityGrade` enum('A','B','C','D','E') NOT NULL,
	`intelligenceEvaluationGrade` int,
	`handlingCode` varchar(50),
	`firstContactDate` timestamp,
	`lastContactDate` timestamp,
	`reportingOfficerId` int NOT NULL,
	`supervisorId` int,
	`notes` text,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sources_id` PRIMARY KEY(`id`),
	CONSTRAINT `sources_sourceIdentifier_unique` UNIQUE(`sourceIdentifier`)
);
--> statement-breakpoint
CREATE TABLE `suspects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`firstName` varchar(100) NOT NULL,
	`lastName` varchar(100) NOT NULL,
	`dateOfBirth` timestamp,
	`aliases` text,
	`physicalDescription` text,
	`knownAddresses` text,
	`riskClassification` enum('low','medium','high','critical') NOT NULL,
	`criminalHistory` text,
	`knownAssociates` text,
	`sourceId` int,
	`linkedCaseIds` text,
	`lastUpdatedBy` int NOT NULL,
	`notes` text,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `suspects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `targets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`targetName` varchar(255) NOT NULL,
	`targetType` enum('individual','organization','infrastructure') NOT NULL,
	`threatType` enum('fraud','robbery','cybercrime','terrorism','trafficking','organized_crime','corruption','other') NOT NULL,
	`vulnerabilityLevel` enum('low','medium','high','critical') NOT NULL,
	`protectiveMeasures` text,
	`relatedSuspectIds` text,
	`location` varchar(255),
	`latitude` decimal(10,8),
	`longitude` decimal(11,8),
	`lastAssessmentDate` timestamp,
	`assessedBy` int,
	`notes` text,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `targets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('admin','intelligence_officer','analyst','supervisor','user') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `mfaEnabled` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `mfaSecret` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `department` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `badgeNumber` varchar(50);--> statement-breakpoint
ALTER TABLE `users` ADD `isActive` boolean DEFAULT true;--> statement-breakpoint
CREATE INDEX `alert_type_idx` ON `alerts` (`alertType`);--> statement-breakpoint
CREATE INDEX `alert_status_idx` ON `alerts` (`status`);--> statement-breakpoint
CREATE INDEX `attachment_report_idx` ON `attachments` (`reportId`);--> statement-breakpoint
CREATE INDEX `uploaded_by_idx` ON `attachments` (`uploadedBy`);--> statement-breakpoint
CREATE INDEX `audit_user_idx` ON `audit_logs` (`userId`);--> statement-breakpoint
CREATE INDEX `audit_created_idx` ON `audit_logs` (`createdAt`);--> statement-breakpoint
CREATE INDEX `entity_type_idx` ON `audit_logs` (`entityType`);--> statement-breakpoint
CREATE INDEX `action_idx` ON `audit_logs` (`action`);--> statement-breakpoint
CREATE INDEX `incident_source_idx` ON `incidents` (`sourceId`);--> statement-breakpoint
CREATE INDEX `reported_by_idx` ON `incidents` (`reportedBy`);--> statement-breakpoint
CREATE INDEX `incident_supervisor_idx` ON `incidents` (`supervisorId`);--> statement-breakpoint
CREATE INDEX `incident_status_idx` ON `incidents` (`status`);--> statement-breakpoint
CREATE INDEX `priority_idx` ON `incidents` (`priority`);--> statement-breakpoint
CREATE INDEX `incident_date_idx` ON `incidents` (`incidentDate`);--> statement-breakpoint
CREATE INDEX `report_source_idx` ON `intelligence_reports` (`sourceId`);--> statement-breakpoint
CREATE INDEX `report_incident_idx` ON `intelligence_reports` (`incidentId`);--> statement-breakpoint
CREATE INDEX `author_idx` ON `intelligence_reports` (`authorId`);--> statement-breakpoint
CREATE INDEX `report_supervisor_idx` ON `intelligence_reports` (`supervisorId`);--> statement-breakpoint
CREATE INDEX `report_status_idx` ON `intelligence_reports` (`status`);--> statement-breakpoint
CREATE INDEX `report_priority_idx` ON `intelligence_reports` (`priority`);--> statement-breakpoint
CREATE INDEX `reporting_officer_idx` ON `sources` (`reportingOfficerId`);--> statement-breakpoint
CREATE INDEX `supervisor_idx` ON `sources` (`supervisorId`);--> statement-breakpoint
CREATE INDEX `source_type_idx` ON `sources` (`sourceType`);--> statement-breakpoint
CREATE INDEX `reliability_idx` ON `sources` (`sourceReliabilityGrade`);--> statement-breakpoint
CREATE INDEX `source_idx` ON `suspects` (`sourceId`);--> statement-breakpoint
CREATE INDEX `last_updated_by_idx` ON `suspects` (`lastUpdatedBy`);--> statement-breakpoint
CREATE INDEX `risk_idx` ON `suspects` (`riskClassification`);--> statement-breakpoint
CREATE INDEX `last_name_idx` ON `suspects` (`lastName`);--> statement-breakpoint
CREATE INDEX `assessed_by_idx` ON `targets` (`assessedBy`);--> statement-breakpoint
CREATE INDEX `threat_type_idx` ON `targets` (`threatType`);--> statement-breakpoint
CREATE INDEX `vulnerability_idx` ON `targets` (`vulnerabilityLevel`);--> statement-breakpoint
CREATE INDEX `role_idx` ON `users` (`role`);