import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json, binary, index } from "drizzle-orm/mysql-core";
import { sql } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extended with law enforcement roles and MFA support.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["admin", "intelligence_officer", "analyst", "supervisor", "user"]).default("user").notNull(),
  mfaEnabled: boolean("mfaEnabled").default(false),
  mfaSecret: varchar("mfaSecret", { length: 255 }),
  department: varchar("department", { length: 255 }),
  badgeNumber: varchar("badgeNumber", { length: 50 }),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => ({
  roleIdx: index("role_idx").on(table.role),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Sources table implementing 5x5x5 grading system
 * Tracks intelligence sources with reliability assessment
 */
export const sources = mysqlTable("sources", {
  id: int("id").autoincrement().primaryKey(),
  sourceType: mysqlEnum("sourceType", ["confidential_informant", "public_tip", "surveillance", "digital_evidence", "agency_report", "undercover", "forensic", "osint"]).notNull(),
  sourceIdentifier: varchar("sourceIdentifier", { length: 255 }).unique(),
  sourceIdentityEncrypted: binary("sourceIdentityEncrypted").notNull(),
  sourceIdentityIV: varchar("sourceIdentityIV", { length: 32 }),
  sourceReliabilityGrade: mysqlEnum("sourceReliabilityGrade", ["A", "B", "C", "D", "E"]).notNull(),
  intelligenceEvaluationGrade: int("intelligenceEvaluationGrade"),
  handlingCode: varchar("handlingCode", { length: 50 }),
  firstContactDate: timestamp("firstContactDate"),
  lastContactDate: timestamp("lastContactDate"),
  reportingOfficerId: int("reportingOfficerId").notNull(),
  supervisorId: int("supervisorId"),
  notes: text("notes"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  reportingOfficerIdx: index("reporting_officer_idx").on(table.reportingOfficerId),
  supervisorIdx: index("supervisor_idx").on(table.supervisorId),
  sourceTypeIdx: index("source_type_idx").on(table.sourceType),
  reliabilityIdx: index("reliability_idx").on(table.sourceReliabilityGrade),
}));

export type Source = typeof sources.$inferSelect;
export type InsertSource = typeof sources.$inferInsert;

/**
 * Suspects table for tracking persons of interest
 */
export const suspects = mysqlTable("suspects", {
  id: int("id").autoincrement().primaryKey(),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dateOfBirth: timestamp("dateOfBirth"),
  aliases: text("aliases"),
  physicalDescription: text("physicalDescription"),
  knownAddresses: text("knownAddresses"),
  riskClassification: mysqlEnum("riskClassification", ["low", "medium", "high", "critical"]).notNull(),
  criminalHistory: text("criminalHistory"),
  knownAssociates: text("knownAssociates"),
  sourceId: int("sourceId"),
  linkedCaseIds: text("linkedCaseIds"),
  lastUpdatedBy: int("lastUpdatedBy").notNull(),
  notes: text("notes"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  sourceIdx: index("source_idx").on(table.sourceId),
  lastUpdatedByIdx: index("last_updated_by_idx").on(table.lastUpdatedBy),
  riskIdx: index("risk_idx").on(table.riskClassification),
  lastNameIdx: index("last_name_idx").on(table.lastName),
}));

export type Suspect = typeof suspects.$inferSelect;
export type InsertSuspect = typeof suspects.$inferInsert;

/**
 * Targets table for tracking individuals, organizations, or infrastructure at risk
 */
export const targets = mysqlTable("targets", {
  id: int("id").autoincrement().primaryKey(),
  targetName: varchar("targetName", { length: 255 }).notNull(),
  targetType: mysqlEnum("targetType", ["individual", "organization", "infrastructure"]).notNull(),
  threatType: mysqlEnum("threatType", ["fraud", "robbery", "cybercrime", "terrorism", "trafficking", "organized_crime", "corruption", "other"]).notNull(),
  vulnerabilityLevel: mysqlEnum("vulnerabilityLevel", ["low", "medium", "high", "critical"]).notNull(),
  protectiveMeasures: text("protectiveMeasures"),
  relatedSuspectIds: text("relatedSuspectIds"),
  location: varchar("location", { length: 255 }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  lastAssessmentDate: timestamp("lastAssessmentDate"),
  assessedBy: int("assessedBy"),
  notes: text("notes"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  assessedByIdx: index("assessed_by_idx").on(table.assessedBy),
  threatTypeIdx: index("threat_type_idx").on(table.threatType),
  vulnerabilityIdx: index("vulnerability_idx").on(table.vulnerabilityLevel),
}));

export type Target = typeof targets.$inferSelect;
export type InsertTarget = typeof targets.$inferInsert;

/**
 * Incidents table for tracking criminal incidents and events
 */
export const incidents = mysqlTable("incidents", {
  id: int("id").autoincrement().primaryKey(),
  incidentTitle: varchar("incidentTitle", { length: 255 }).notNull(),
  incidentDate: timestamp("incidentDate").notNull(),
  incidentLocation: varchar("incidentLocation", { length: 255 }),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  incidentType: varchar("incidentType", { length: 100 }),
  description: text("description").notNull(),
  relatedSuspectIds: text("relatedSuspectIds"),
  relatedTargetIds: text("relatedTargetIds"),
  sourceId: int("sourceId"),
  reportedBy: int("reportedBy").notNull(),
  supervisorId: int("supervisorId"),
  status: mysqlEnum("status", ["open", "under_investigation", "closed"]).default("open"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  sourceIdx: index("incident_source_idx").on(table.sourceId),
  reportedByIdx: index("reported_by_idx").on(table.reportedBy),
  supervisorIdx: index("incident_supervisor_idx").on(table.supervisorId),
  statusIdx: index("incident_status_idx").on(table.status),
  priorityIdx: index("priority_idx").on(table.priority),
  incidentDateIdx: index("incident_date_idx").on(table.incidentDate),
}));

export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = typeof incidents.$inferInsert;

/**
 * Intelligence reports table for structured intelligence documentation
 */
export const intelligenceReports = mysqlTable("intelligence_reports", {
  id: int("id").autoincrement().primaryKey(),
  reportTitle: varchar("reportTitle", { length: 255 }).notNull(),
  reportContent: text("reportContent").notNull(),
  reportType: varchar("reportType", { length: 100 }),
  sourceId: int("sourceId").notNull(),
  incidentId: int("incidentId"),
  authorId: int("authorId").notNull(),
  supervisorId: int("supervisorId"),
  status: mysqlEnum("status", ["draft", "submitted", "under_review", "approved", "rejected"]).default("draft"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium"),
  confidentialityLevel: mysqlEnum("confidentialityLevel", ["public", "internal", "restricted", "confidential"]).default("restricted"),
  relatedSuspectIds: text("relatedSuspectIds"),
  relatedTargetIds: text("relatedTargetIds"),
  extractedEntities: json("extractedEntities"),
  extractedRelationships: json("extractedRelationships"),
  riskAssessment: json("riskAssessment"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  submittedAt: timestamp("submittedAt"),
  approvedAt: timestamp("approvedAt"),
}, (table) => ({
  sourceIdx: index("report_source_idx").on(table.sourceId),
  incidentIdx: index("report_incident_idx").on(table.incidentId),
  authorIdx: index("author_idx").on(table.authorId),
  supervisorIdx: index("report_supervisor_idx").on(table.supervisorId),
  statusIdx: index("report_status_idx").on(table.status),
  priorityIdx: index("report_priority_idx").on(table.priority),
}));

export type IntelligenceReport = typeof intelligenceReports.$inferSelect;
export type InsertIntelligenceReport = typeof intelligenceReports.$inferInsert;

/**
 * Attachments table for report documents and media
 */
export const attachments = mysqlTable("attachments", {
  id: int("id").autoincrement().primaryKey(),
  reportId: int("reportId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileType: varchar("fileType", { length: 50 }),
  fileSize: int("fileSize"),
  s3Key: varchar("s3Key", { length: 500 }),
  s3Url: text("s3Url"),
  uploadedBy: int("uploadedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  reportIdx: index("attachment_report_idx").on(table.reportId),
  uploadedByIdx: index("uploaded_by_idx").on(table.uploadedBy),
}));

export type Attachment = typeof attachments.$inferSelect;
export type InsertAttachment = typeof attachments.$inferInsert;

/**
 * Audit logs table for compliance and security tracking
 */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entityType", { length: 50 }),
  entityId: int("entityId"),
  oldValue: json("oldValue"),
  newValue: json("newValue"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  userAgent: text("userAgent"),
  status: mysqlEnum("status", ["success", "failure"]).default("success"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("audit_user_idx").on(table.userId),
  createdAtIdx: index("audit_created_idx").on(table.createdAt),
  entityTypeIdx: index("entity_type_idx").on(table.entityType),
  actionIdx: index("action_idx").on(table.action),
}));

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * Alerts table for notifications and critical events
 */
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  alertType: mysqlEnum("alertType", ["critical_incident", "high_risk_suspect", "urgent_review", "system_alert"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  relatedEntityType: varchar("relatedEntityType", { length: 50 }),
  relatedEntityId: int("relatedEntityId"),
  recipientIds: text("recipientIds"),
  sentAt: timestamp("sentAt"),
  readAt: timestamp("readAt"),
  emailSentAt: timestamp("emailSentAt"),
  status: mysqlEnum("status", ["pending", "sent", "read"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  alertTypeIdx: index("alert_type_idx").on(table.alertType),
  statusIdx: index("alert_status_idx").on(table.status),
}));

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;