import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Users, Target, FileText, MapPin, Shield, LogOut } from 'lucide-react';
import DashboardLayout from './DashboardLayout';

export default function CrimeIntelDashboard() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  const suspectsList = trpc.suspects.list.useQuery();
  const targetsList = trpc.targets.list.useQuery();
  const incidentsList = trpc.incidents.list.useQuery();
  const reportsList = trpc.reports.list.useQuery();
  const alertsList = trpc.alerts.list.useQuery();

  const canCreateIntelligence = user?.role === 'intelligence_officer' || user?.role === 'admin';
  const canAnalyze = user?.role === 'analyst' || user?.role === 'admin';
  const canSupervise = user?.role === 'supervisor' || user?.role === 'admin';
  const isAdmin = user?.role === 'admin';

  const handleLogout = async () => {
    await logout();
  };

  const stats = [
    {
      title: 'Active Suspects',
      value: suspectsList.data?.length || 0,
      icon: Users,
      color: 'bg-red-100 text-red-700',
    },
    {
      title: 'Monitored Targets',
      value: targetsList.data?.length || 0,
      icon: Target,
      color: 'bg-orange-100 text-orange-700',
    },
    {
      title: 'Open Incidents',
      value: incidentsList.data?.filter((i: any) => i.status === 'open').length || 0,
      icon: AlertCircle,
      color: 'bg-yellow-100 text-yellow-700',
    },
    {
      title: 'Pending Reports',
      value: reportsList.data?.filter((r: any) => r.status === 'draft' || r.status === 'submitted').length || 0,
      icon: FileText,
      color: 'bg-blue-100 text-blue-700',
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Crime Intelligence System</h1>
            <p className="text-gray-600 mt-1">
              Welcome, {user?.name} • {user?.role?.replace(/_/g, ' ').toUpperCase()}
            </p>
          </div>
          <Button variant="outline" onClick={handleLogout} className="gap-2">
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.title}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-gray-600">
                      {stat.title}
                    </CardTitle>
                    <div className={`p-2 rounded-lg ${stat.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Content Tabs */}
        <Card>
          <CardHeader>
            <CardTitle>Intelligence Management</CardTitle>
            <CardDescription>
              Access and manage all intelligence modules
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                {canCreateIntelligence && <TabsTrigger value="sources">Sources</TabsTrigger>}
                {canCreateIntelligence && <TabsTrigger value="suspects">Suspects</TabsTrigger>}
                {canCreateIntelligence && <TabsTrigger value="targets">Targets</TabsTrigger>}
                {canAnalyze && <TabsTrigger value="reports">Reports</TabsTrigger>}
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Recent Incidents</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {incidentsList.data && incidentsList.data.length > 0 ? (
                        <div className="space-y-2">
                          {incidentsList.data.slice(0, 5).map((incident: any) => (
                            <div key={incident.id} className="p-2 border rounded text-sm">
                              <p className="font-medium">{incident.incidentTitle}</p>
                              <p className="text-xs text-gray-500">
                                {new Date(incident.incidentDate).toLocaleDateString()}
                              </p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-sm">No incidents recorded</p>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">System Alerts</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {alertsList.data && alertsList.data.length > 0 ? (
                        <div className="space-y-2">
                          {alertsList.data.slice(0, 5).map((alert: any) => (
                            <div key={alert.id} className="p-2 border rounded text-sm">
                              <p className="font-medium">{alert.title}</p>
                              <p className="text-xs text-gray-500">{alert.alertType}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-sm">No active alerts</p>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {canCreateIntelligence && (
                <TabsContent value="sources" className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h3 className="font-semibold text-blue-900">Intelligence Sources</h3>
                    <p className="text-sm text-blue-700 mt-1">
                      Manage and track intelligence sources with 5x5x5 reliability grading
                    </p>
                  </div>
                  <Button className="gap-2">
                    <Shield className="w-4 h-4" />
                    Add New Source
                  </Button>
                </TabsContent>
              )}

              {canCreateIntelligence && (
                <TabsContent value="suspects" className="space-y-4">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h3 className="font-semibold text-red-900">Suspect Profiles</h3>
                    <p className="text-sm text-red-700 mt-1">
                      Track persons of interest with risk classification and known associates
                    </p>
                  </div>
                  <div className="space-y-2">
                    {suspectsList.data && suspectsList.data.length > 0 ? (
                      suspectsList.data.map((suspect: any) => (
                        <Card key={suspect.id}>
                          <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-semibold">
                                  {suspect.firstName} {suspect.lastName}
                                </p>
                                <p className="text-sm text-gray-600">
                                  Risk: {suspect.riskClassification}
                                </p>
                              </div>
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    ) : (
                      <p className="text-gray-500 text-sm">No suspects recorded</p>
                    )}
                  </div>
                </TabsContent>
              )}

              {canCreateIntelligence && (
                <TabsContent value="targets" className="space-y-4">
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h3 className="font-semibold text-orange-900">Target Management</h3>
                    <p className="text-sm text-orange-700 mt-1">
                      Monitor individuals, organizations, and infrastructure at risk
                    </p>
                  </div>
                  <div className="space-y-2">
                    {targetsList.data && targetsList.data.length > 0 ? (
                      targetsList.data.map((target: any) => (
                        <Card key={target.id}>
                          <CardContent className="pt-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-semibold">{target.targetName}</p>
                                <p className="text-sm text-gray-600">
                                  {target.targetType} • Threat: {target.threatType}
                                </p>
                              </div>
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    ) : (
                      <p className="text-gray-500 text-sm">No targets recorded</p>
                    )}
                  </div>
                </TabsContent>
              )}

              {canAnalyze && (
                <TabsContent value="reports" className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h3 className="font-semibold text-green-900">Intelligence Reports</h3>
                    <p className="text-sm text-green-700 mt-1">
                      Create and manage structured intelligence reports
                    </p>
                  </div>
                  <Button className="gap-2">
                    <FileText className="w-4 h-4" />
                    Create New Report
                  </Button>
                </TabsContent>
              )}
            </Tabs>
          </CardContent>
        </Card>

        {/* Footer Info */}
        <Card className="bg-gray-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-gray-700">
                <p className="font-semibold">Security Notice</p>
                <p className="mt-1">
                  All activities are logged for compliance and audit purposes. Unauthorized access is prohibited.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
