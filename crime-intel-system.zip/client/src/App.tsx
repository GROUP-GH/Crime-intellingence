import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import CrimeIntelDashboard from "./components/CrimeIntelDashboard";
import SourceManagement from "./pages/SourceManagement";
import SuspectManagement from "./pages/SuspectManagement";
import TargetManagement from "./pages/TargetManagement";
import IncidentManagement from "./pages/IncidentManagement";
import ReportManagement from "./pages/ReportManagement";
import Analytics from "./pages/Analytics";
import AuditLogs from "./pages/AuditLogs";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={CrimeIntelDashboard} />
      <Route path={"/sources"} component={SourceManagement} />
      <Route path={"/suspects"} component={SuspectManagement} />
      <Route path={"/targets"} component={TargetManagement} />
      <Route path={"/incidents"} component={IncidentManagement} />
      <Route path={"/reports"} component={ReportManagement} />
      <Route path={"/analytics"} component={Analytics} />
      <Route path={"/audit"} component={AuditLogs} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
