import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Users, Target, FileText, MapPin, BarChart3, Lock, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // Redirect authenticated users to dashboard
  if (isAuthenticated && !loading) {
    navigate("/dashboard");
    return null;
  }

  const features = [
    {
      icon: Shield,
      title: "Role-Based Access Control",
      description: "Admin, Intelligence Officer, Analyst, and Supervisor roles with granular permissions",
    },
    {
      icon: Users,
      title: "Suspect Management",
      description: "Track persons of interest with risk classification and known associates",
    },
    {
      icon: Target,
      title: "Target Monitoring",
      description: "Monitor individuals, organizations, and infrastructure at risk",
    },
    {
      icon: FileText,
      title: "Intelligence Reports",
      description: "Create and manage structured intelligence reports with attachments",
    },
    {
      icon: MapPin,
      title: "Geographic Mapping",
      description: "Visualize incidents and threats on interactive maps with heatmaps",
    },
    {
      icon: BarChart3,
      title: "Analytics Dashboard",
      description: "Threat trends, risk heatmaps, and pattern analysis",
    },
    {
      icon: Lock,
      title: "Data Encryption",
      description: "AES-256 encryption for sensitive source identities and data",
    },
    {
      icon: Zap,
      title: "Automated Alerts",
      description: "Real-time notifications for critical incidents and high-risk suspects",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-900">
      {/* Navigation */}
      <nav className="border-b border-blue-700 bg-blue-900/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-white" />
            <span className="text-xl font-bold text-white">Crime Intelligence System</span>
          </div>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button className="bg-white text-blue-900 hover:bg-blue-50">
                Sign In
              </Button>
            </a>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-20">
          <h1 className="text-5xl font-bold text-white mb-6">
            Secure Intelligence & Threat Monitoring
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            A comprehensive platform for law enforcement and security agencies to manage, analyze, and respond to criminal intelligence with full compliance and audit trails.
          </p>
          <div className="flex gap-4 justify-center">
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-white text-blue-900 hover:bg-blue-50 px-8">
                Get Started
              </Button>
            </a>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-blue-800 px-8">
              Learn More
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Card key={feature.title} className="bg-blue-800/50 border-blue-700 hover:bg-blue-800/70 transition-colors">
                <CardHeader>
                  <Icon className="w-8 h-8 text-blue-300 mb-2" />
                  <CardTitle className="text-white text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-blue-100 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Key Capabilities */}
        <Card className="bg-blue-800/50 border-blue-700 mb-20">
          <CardHeader>
            <CardTitle className="text-white text-2xl">Key Capabilities</CardTitle>
            <CardDescription className="text-blue-200">
              Comprehensive intelligence management for law enforcement
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6 text-blue-100">
              <div>
                <h3 className="font-semibold text-white mb-2">Source Management</h3>
                <ul className="space-y-1 text-sm">
                  <li>• 5x5x5 reliability grading system</li>
                  <li>• Confidential informant handling</li>
                  <li>• Source identity encryption</li>
                  <li>• Handling code tracking</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-2">Compliance & Security</h3>
                <ul className="space-y-1 text-sm">
                  <li>• 28 CFR Part 23 compliance</li>
                  <li>• CJIS security standards</li>
                  <li>• Complete audit trails</li>
                  <li>• Multi-factor authentication</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-2">Intelligence Analysis</h3>
                <ul className="space-y-1 text-sm">
                  <li>• NLP entity extraction</li>
                  <li>• Pattern recognition</li>
                  <li>• Risk assessment automation</li>
                  <li>• Relationship mapping</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-2">Incident Management</h3>
                <ul className="space-y-1 text-sm">
                  <li>• Structured reporting</li>
                  <li>• Status tracking</li>
                  <li>• Geographic mapping</li>
                  <li>• Alert automation</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center bg-blue-700/50 rounded-lg p-12 border border-blue-600">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Enhance Your Intelligence Operations?
          </h2>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto">
            Deploy a secure, compliant intelligence management system designed specifically for law enforcement and security agencies.
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-white text-blue-900 hover:bg-blue-50 px-8">
              Sign In Now
            </Button>
          </a>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-blue-700 bg-blue-900/50 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-white font-semibold mb-4">About</h3>
              <p className="text-blue-200 text-sm">
                Enterprise-grade intelligence management system for authorized law enforcement and security agencies.
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Compliance</h3>
              <ul className="text-blue-200 text-sm space-y-1">
                <li>• 28 CFR Part 23</li>
                <li>• CJIS Standards</li>
                <li>• Data Protection Laws</li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Security</h3>
              <ul className="text-blue-200 text-sm space-y-1">
                <li>• AES-256 Encryption</li>
                <li>• Multi-Factor Auth</li>
                <li>• Audit Logging</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-blue-700 pt-8 text-center text-blue-300 text-sm">
            <p>&copy; 2026 Crime Intelligence System. All rights reserved. Authorized use only.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
