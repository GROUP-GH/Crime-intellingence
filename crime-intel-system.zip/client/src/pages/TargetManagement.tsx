import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';

export default function TargetManagement() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Target Management</h1>
        <Card>
          <CardContent className="pt-6">
            <p className="text-gray-600">Target management module coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
