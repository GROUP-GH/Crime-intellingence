import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Shield, Filter } from 'lucide-react';
import DashboardLayout from '@/components/DashboardLayout';

export default function SourceManagement() {
  const { user } = useAuth();
  const [sourceType, setSourceType] = useState('');
  const [reliabilityGrade, setReliabilityGrade] = useState('');
  
  const sourcesList = trpc.sources.list.useQuery({
    sourceType: sourceType || undefined,
    reliabilityGrade: reliabilityGrade || undefined,
  });

  const canCreate = user?.role === 'intelligence_officer' || user?.role === 'admin';

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Intelligence Sources</h1>
            <p className="text-gray-600 mt-1">
              Manage intelligence sources with 5x5x5 reliability grading system
            </p>
          </div>
          {canCreate && (
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add New Source
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filter Sources
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Source Type</label>
                <Select value={sourceType} onValueChange={setSourceType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All types</SelectItem>
                    <SelectItem value="confidential_informant">Confidential Informant</SelectItem>
                    <SelectItem value="public_tip">Public Tip</SelectItem>
                    <SelectItem value="surveillance">Surveillance</SelectItem>
                    <SelectItem value="digital_evidence">Digital Evidence</SelectItem>
                    <SelectItem value="agency_report">Agency Report</SelectItem>
                    <SelectItem value="undercover">Undercover</SelectItem>
                    <SelectItem value="forensic">Forensic</SelectItem>
                    <SelectItem value="osint">OSINT</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Reliability Grade</label>
                <Select value={reliabilityGrade} onValueChange={setReliabilityGrade}>
                  <SelectTrigger>
                    <SelectValue placeholder="All grades" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All grades</SelectItem>
                    <SelectItem value="A">A - Highly Reliable</SelectItem>
                    <SelectItem value="B">B - Reliable</SelectItem>
                    <SelectItem value="C">C - Moderately Reliable</SelectItem>
                    <SelectItem value="D">D - Unreliable</SelectItem>
                    <SelectItem value="E">E - Unverified</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sources List */}
        <div className="space-y-3">
          {sourcesList.isLoading ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-500">Loading sources...</p>
              </CardContent>
            </Card>
          ) : sourcesList.data && sourcesList.data.length > 0 ? (
            sourcesList.data.map((source: any) => (
              <Card key={source.id} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            {source.sourceType.replace(/_/g, ' ').toUpperCase()}
                          </h3>
                          <p className="text-sm text-gray-600">
                            ID: {source.sourceIdentifier || 'Confidential'}
                          </p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-sm">
                        <div>
                          <p className="text-gray-600">Reliability Grade</p>
                          <p className="font-semibold text-lg">{source.sourceReliabilityGrade}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Intelligence Eval</p>
                          <p className="font-semibold">{source.intelligenceEvaluationGrade || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">First Contact</p>
                          <p className="font-semibold text-sm">
                            {source.firstContactDate ? new Date(source.firstContactDate).toLocaleDateString() : 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600">Status</p>
                          <p className="font-semibold">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              source.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {source.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </p>
                        </div>
                      </div>
                      {source.notes && (
                        <p className="text-sm text-gray-600 mt-3 p-2 bg-gray-50 rounded">
                          {source.notes}
                        </p>
                      )}
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-500 text-center">No sources found</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Information Card */}
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-base">5x5x5 Reliability Grading System</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-gray-700 space-y-1">
            <p><strong>Grade A:</strong> Highly reliable source with proven accuracy</p>
            <p><strong>Grade B:</strong> Reliable source with generally accurate information</p>
            <p><strong>Grade C:</strong> Moderately reliable, some verification needed</p>
            <p><strong>Grade D:</strong> Unreliable source, information requires verification</p>
            <p><strong>Grade E:</strong> Unverified source, no track record established</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
