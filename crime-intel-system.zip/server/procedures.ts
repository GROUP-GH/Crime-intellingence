import { TRPCError } from "@trpc/server";
import { protectedProcedure } from "./_core/trpc";

/**
 * Admin-only procedure
 * Restricted to users with 'admin' role
 */
export const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user?.role !== 'admin') {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Only administrators can perform this action',
    });
  }
  return next({ ctx });
});

/**
 * Intelligence Officer procedure
 * Restricted to Intelligence Officers and Admins
 */
export const intelligenceOfficerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!ctx.user || (ctx.user.role !== 'intelligence_officer' && ctx.user.role !== 'admin')) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Only intelligence officers can perform this action',
    });
  }
  return next({ ctx });
});

/**
 * Analyst procedure
 * Restricted to Analysts and Admins
 */
export const analystProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!ctx.user || (ctx.user.role !== 'analyst' && ctx.user.role !== 'admin')) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Only analysts can perform this action',
    });
  }
  return next({ ctx });
});

/**
 * Supervisor procedure
 * Restricted to Supervisors and Admins
 */
export const supervisorProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!ctx.user || (ctx.user.role !== 'supervisor' && ctx.user.role !== 'admin')) {
    throw new TRPCError({
      code: 'FORBIDDEN',
      message: 'Only supervisors can perform this action',
    });
  }
  return next({ ctx });
});
