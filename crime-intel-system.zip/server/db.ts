import { eq, and, desc, asc, like, inArray, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  InsertSource, sources,
  InsertSuspect, suspects,
  InsertTarget, targets,
  InsertIncident, incidents,
  InsertIntelligenceReport, intelligenceReports,
  InsertAttachment, attachments,
  InsertAuditLog, auditLogs,
  InsertAlert, alerts
} from "../drizzle/schema";
import { ENV } from './_core/env';
import { encryptData, decryptData, hashIdentifier } from './encryption';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER OPERATIONS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(users).where(eq(users.isActive, true));
}

// ============ SOURCE OPERATIONS ============

export async function createSource(source: InsertSource & { sourceIdentity: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const { sourceIdentity, ...sourceData } = source;
  const { encrypted, iv, authTag } = encryptData(sourceIdentity);
  
  const result = await db.insert(sources).values({
    ...sourceData,
    sourceIdentityEncrypted: encrypted.toString('hex'),
    sourceIdentityIV: iv,
  } as any);
  
  return result;
}

export async function getSourceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(sources).where(eq(sources.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listSources(filters?: { sourceType?: string; reliabilityGrade?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(sources).where(eq(sources.isActive, true));
  
  if (filters?.sourceType) {
    query = query.where(eq(sources.sourceType, filters.sourceType as any));
  }
  if (filters?.reliabilityGrade) {
    query = query.where(eq(sources.sourceReliabilityGrade, filters.reliabilityGrade as any));
  }
  
  return await query.orderBy(desc(sources.createdAt));
}

// ============ SUSPECT OPERATIONS ============

export async function createSuspect(suspect: InsertSuspect) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(suspects).values(suspect);
  return result;
}

export async function getSuspectById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(suspects).where(eq(suspects.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listSuspects(filters?: { riskLevel?: string; lastName?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(suspects).where(eq(suspects.isActive, true));
  
  if (filters?.riskLevel) {
    query = query.where(eq(suspects.riskClassification, filters.riskLevel as any));
  }
  if (filters?.lastName) {
    query = query.where(like(suspects.lastName, `%${filters.lastName}%`));
  }
  
  return await query.orderBy(desc(suspects.createdAt));
}

// ============ TARGET OPERATIONS ============

export async function createTarget(target: InsertTarget) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(targets).values(target);
  return result;
}

export async function getTargetById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(targets).where(eq(targets.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listTargets(filters?: { threatType?: string; vulnerabilityLevel?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(targets).where(eq(targets.isActive, true));
  
  if (filters?.threatType) {
    query = query.where(eq(targets.threatType, filters.threatType as any));
  }
  if (filters?.vulnerabilityLevel) {
    query = query.where(eq(targets.vulnerabilityLevel, filters.vulnerabilityLevel as any));
  }
  
  return await query.orderBy(desc(targets.createdAt));
}

// ============ INCIDENT OPERATIONS ============

export async function createIncident(incident: InsertIncident) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(incidents).values(incident);
  return result;
}

export async function getIncidentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(incidents).where(eq(incidents.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listIncidents(filters?: { status?: string; priority?: string; dateRange?: [Date, Date] }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(incidents);
  
  if (filters?.status) {
    query = query.where(eq(incidents.status, filters.status as any));
  }
  if (filters?.priority) {
    query = query.where(eq(incidents.priority, filters.priority as any));
  }
  if (filters?.dateRange) {
    const [startDate, endDate] = filters.dateRange;
    query = query.where(and(
      gte(incidents.incidentDate, startDate),
      lte(incidents.incidentDate, endDate)
    ));
  }
  
  return await query.orderBy(desc(incidents.incidentDate));
}

// ============ INTELLIGENCE REPORT OPERATIONS ============

export async function createReport(report: InsertIntelligenceReport) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(intelligenceReports).values(report);
  return result;
}

export async function getReportById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(intelligenceReports).where(eq(intelligenceReports.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listReports(filters?: { status?: string; authorId?: number; dateRange?: [Date, Date] }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(intelligenceReports);
  
  if (filters?.status) {
    query = query.where(eq(intelligenceReports.status, filters.status as any));
  }
  if (filters?.authorId) {
    query = query.where(eq(intelligenceReports.authorId, filters.authorId));
  }
  if (filters?.dateRange) {
    const [startDate, endDate] = filters.dateRange;
    query = query.where(and(
      gte(intelligenceReports.createdAt, startDate),
      lte(intelligenceReports.createdAt, endDate)
    ));
  }
  
  return await query.orderBy(desc(intelligenceReports.createdAt));
}

// ============ ATTACHMENT OPERATIONS ============

export async function createAttachment(attachment: InsertAttachment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(attachments).values(attachment);
  return result;
}

export async function listAttachmentsByReport(reportId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(attachments).where(eq(attachments.reportId, reportId));
}

// ============ AUDIT LOG OPERATIONS ============

export async function createAuditLog(log: InsertAuditLog) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(auditLogs).values(log);
  return result;
}

export async function listAuditLogs(filters?: { userId?: number; action?: string; dateRange?: [Date, Date] }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(auditLogs);
  
  if (filters?.userId) {
    query = query.where(eq(auditLogs.userId, filters.userId));
  }
  if (filters?.action) {
    query = query.where(eq(auditLogs.action, filters.action));
  }
  if (filters?.dateRange) {
    const [startDate, endDate] = filters.dateRange;
    query = query.where(and(
      gte(auditLogs.createdAt, startDate),
      lte(auditLogs.createdAt, endDate)
    ));
  }
  
  return await query.orderBy(desc(auditLogs.createdAt));
}

// ============ ALERT OPERATIONS ============

export async function createAlert(alert: InsertAlert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(alerts).values(alert);
  return result;
}

export async function listAlerts(filters?: { status?: string; alertType?: string }) {
  const db = await getDb();
  if (!db) return [];
  
  let query: any = db.select().from(alerts);
  
  if (filters?.status) {
    query = query.where(eq(alerts.status, filters.status as any));
  }
  if (filters?.alertType) {
    query = query.where(eq(alerts.alertType, filters.alertType as any));
  }
  
  return await query.orderBy(desc(alerts.createdAt));
}
