import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { adminProcedure, intelligenceOfficerProcedure, analystProcedure, supervisorProcedure } from "./procedures";
import { z } from "zod";
import * as db from "./db";
import { createAuditLog } from "./db";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ SOURCE MANAGEMENT ============
  sources: router({
    create: intelligenceOfficerProcedure
      .input(z.object({
        sourceType: z.enum(["confidential_informant", "public_tip", "surveillance", "digital_evidence", "agency_report", "undercover", "forensic", "osint"]),
        sourceIdentity: z.string().min(1),
        sourceReliabilityGrade: z.enum(["A", "B", "C", "D", "E"]),
        intelligenceEvaluationGrade: z.number().int().min(1).max(5).optional(),
        handlingCode: z.string().optional(),
        supervisorId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { sourceIdentity, ...sourceData } = input;
        const source = await db.createSource({
          ...sourceData,
          sourceIdentity,
          reportingOfficerId: ctx.user!.id,
          firstContactDate: new Date(),
          lastContactDate: new Date(),
          isActive: true,
        } as any);
        
        await createAuditLog({
          userId: ctx.user!.id,
          action: 'create_source',
          entityType: 'source',
          status: 'success',
        });
        
        return source;
      }),

    list: protectedProcedure
      .input(z.object({
        sourceType: z.string().optional(),
        reliabilityGrade: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listSources(input);
      }),

    getById: protectedProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return db.getSourceById(input);
      }),
  }),

  // ============ SUSPECT MANAGEMENT ============
  suspects: router({
    create: intelligenceOfficerProcedure
      .input(z.object({
        firstName: z.string().min(1),
        lastName: z.string().min(1),
        dateOfBirth: z.date().optional(),
        aliases: z.string().optional(),
        physicalDescription: z.string().optional(),
        knownAddresses: z.string().optional(),
        riskClassification: z.enum(["low", "medium", "high", "critical"]),
        criminalHistory: z.string().optional(),
        knownAssociates: z.string().optional(),
        sourceId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const suspect = await db.createSuspect({
          ...input,
          lastUpdatedBy: ctx.user!.id,
          isActive: true,
        });
        
        await createAuditLog({
          userId: ctx.user!.id,
          action: 'create_suspect',
          entityType: 'suspect',
          status: 'success',
        });
        
        return suspect;
      }),

    list: protectedProcedure
      .input(z.object({
        riskLevel: z.string().optional(),
        lastName: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listSuspects(input);
      }),

    getById: protectedProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return db.getSuspectById(input);
      }),
  }),

  // ============ TARGET MANAGEMENT ============
  targets: router({
    create: intelligenceOfficerProcedure
      .input(z.object({
        targetName: z.string().min(1),
        targetType: z.enum(["individual", "organization", "infrastructure"]),
        threatType: z.enum(["fraud", "robbery", "cybercrime", "terrorism", "trafficking", "organized_crime", "corruption", "other"]),
        vulnerabilityLevel: z.enum(["low", "medium", "high", "critical"]),
        protectiveMeasures: z.string().optional(),
        relatedSuspectIds: z.string().optional(),
        location: z.string().optional(),
        latitude: z.number().optional(),
        longitude: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const target = await db.createTarget({
          ...input,
          assessedBy: ctx.user!.id,
          lastAssessmentDate: new Date(),
          isActive: true,
        } as any);
        
        await createAuditLog({
          userId: ctx.user!.id,
          action: 'create_target',
          entityType: 'target',
          status: 'success',
        });
        
        return target;
      }),

    list: protectedProcedure
      .input(z.object({
        threatType: z.string().optional(),
        vulnerabilityLevel: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listTargets(input);
      }),

    getById: protectedProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return db.getTargetById(input);
      }),
  }),

  // ============ INCIDENT MANAGEMENT ============
  incidents: router({
    create: intelligenceOfficerProcedure
      .input(z.object({
        incidentTitle: z.string().min(1),
        incidentDate: z.date(),
        incidentLocation: z.string().optional(),
        latitude: z.number().optional(),
        longitude: z.number().optional(),
        incidentType: z.string().optional(),
        description: z.string().min(1),
        relatedSuspectIds: z.string().optional(),
        relatedTargetIds: z.string().optional(),
        sourceId: z.number().optional(),
        supervisorId: z.number().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const incident = await db.createIncident({
          incidentTitle: input.incidentTitle,
          incidentDate: input.incidentDate,
          incidentLocation: input.incidentLocation,
          latitude: input.latitude?.toString() as any,
          longitude: input.longitude?.toString() as any,
          incidentType: input.incidentType,
          description: input.description,
          relatedSuspectIds: input.relatedSuspectIds,
          relatedTargetIds: input.relatedTargetIds,
          sourceId: input.sourceId,
          supervisorId: input.supervisorId,
          reportedBy: ctx.user!.id,
          status: 'open',
          priority: input.priority,
        });
        
        await createAuditLog({
          userId: ctx.user!.id,
          action: 'create_incident',
          entityType: 'incident',
          status: 'success',
        });
        
        return incident;
      }),

    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        priority: z.string().optional(),
        dateRange: z.tuple([z.date(), z.date()]).optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listIncidents(input);
      }),

    getById: protectedProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return db.getIncidentById(input);
      }),
  }),

  // ============ INTELLIGENCE REPORTS ============
  reports: router({
    create: analystProcedure
      .input(z.object({
        reportTitle: z.string().min(1),
        reportContent: z.string().min(1),
        reportType: z.string().optional(),
        sourceId: z.number(),
        incidentId: z.number().optional(),
        supervisorId: z.number().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        confidentialityLevel: z.enum(["public", "internal", "restricted", "confidential"]).optional(),
        relatedSuspectIds: z.string().optional(),
        relatedTargetIds: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const report = await db.createReport({
          ...input,
          authorId: ctx.user!.id,
          status: 'draft',
        });
        
        await createAuditLog({
          userId: ctx.user!.id,
          action: 'create_report',
          entityType: 'intelligence_report',
          status: 'success',
        });
        
        return report;
      }),

    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        authorId: z.number().optional(),
        dateRange: z.tuple([z.date(), z.date()]).optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listReports(input);
      }),

    getById: protectedProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return db.getReportById(input);
      }),
  }),

  // ============ AUDIT & COMPLIANCE ============
  auditLogs: router({
    list: adminProcedure
      .input(z.object({
        userId: z.number().optional(),
        action: z.string().optional(),
        dateRange: z.tuple([z.date(), z.date()]).optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listAuditLogs(input);
      }),
  }),

  // ============ ALERTS ============
  alerts: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        alertType: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return db.listAlerts(input);
      }),
  }),

  // ============ ADMIN FUNCTIONS ============
  admin: router({
    listUsers: adminProcedure
      .query(async () => {
        return db.listUsers();
      }),

    getSystemHealth: adminProcedure
      .query(async () => {
        return {
          status: 'healthy',
          timestamp: new Date(),
          database: 'connected',
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
